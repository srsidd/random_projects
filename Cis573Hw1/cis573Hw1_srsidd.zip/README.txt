In this folder, you'll find the java project for homework 1. You will also find the PDF which provides some insight about the implemented code after an initial analysis.

There is only one class- Main which takes in a single argument. This argument is the path to the corpus. The program can handle both relative and  absolute directory paths for the corpus. 
